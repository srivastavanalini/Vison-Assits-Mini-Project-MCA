# Real-Time Vision Assist

Production-oriented web app with two modes:

- **On-device (free):** TensorFlow.js COCO-SSD runs in the browser with no API keys and no backend. Speech uses the Web Speech API.
- **AWS cloud:** frames go to the FastAPI backend; OpenCV decodes and resizes them, Rekognition detects labels, and Polly speaks the results.

## Folder Structure

```text
clear-view-sound-main/
├── backend/
│   ├── main.py                 # FastAPI app, /api/analyze, /api/health, /api/aws/status
│   ├── config.py               # Settings from environment
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── .env                    # Local AWS/backend config (not committed)
│   └── services/
│       ├── camera_processor.py # OpenCV decode + resize + JPEG encode
│       ├── detection.py        # Rekognition + narration + deduplication
│       └── speech.py           # Polly MP3 -> base64
├── src/                        # React + Vite + Tailwind
├── package.json
├── vite.config.ts              # Dev proxy: /api -> http://127.0.0.1:8000
└── README.md
```

## Prerequisites

- Node.js 20+
- Python 3.11+ for AWS mode
- AWS account with Rekognition and Polly access for AWS mode

## On-Device Mode

1. From the repo root, install and run the frontend:

```bash
npm install
npm run dev
```

2. Open the Vite URL, choose **On-device (free)**, and allow camera access.

No backend is required for this mode.

## AWS Mode Setup

1. Create a backend virtual environment and install dependencies:

```bash
cd backend
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

2. Create `backend/.env`.

3. Set:

- `AWS_REGION`
- `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`
  or omit both and use the default AWS credential chain / profile
- `POLLY_VOICE_ID`
- `REKOGNITION_MIN_CONFIDENCE` if you want a different threshold

4. Start the API:

```bash
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

5. Verify AWS readiness:

```bash
curl http://127.0.0.1:8000/api/aws/status
```

The response reports whether AWS is ready, which region is active, and where credentials were discovered from.

If you leave the key fields blank in `backend/.env`, boto3 will fall back to your local AWS profile or other configured credential sources.

6. In a second terminal, from the repo root:

```bash
npm run dev
```

The frontend dev server runs on port 8080 and proxies `/api` to the FastAPI app on port 8000.

## AWS Configuration Notes

- Use one region for Rekognition, Polly, and credentials. `us-east-1` works well with `Joanna`.
- Minimum required IAM actions:
  - `rekognition:DetectLabels`
  - `polly:SynthesizeSpeech`
- The app now exposes `/api/aws/status` so the frontend can block AWS detection until setup is valid.

## Behavior Notes

- Frames are sent about every 1.5 seconds while AWS detection is on.
- Labels below 60% confidence are dropped by default.
- Speech uses a cooldown so the same narration is not repeated continuously.
- OpenCV is used on the server to decode incoming JPEGs and optionally downscale them before Rekognition.

## Docker

```bash
docker compose up --build
```

Build the frontend separately and point `VITE_API_URL` at the API host for production deployments.

## Deployment Checklist

- Run FastAPI behind HTTPS.
- Restrict CORS in `backend/main.py` to your frontend origin.
- Store secrets in your platform secret manager instead of committed files.
- Set `VITE_API_URL` at build time for the SPA.
