import { RefObject } from "react";
import { Camera, CameraOff } from "lucide-react";
import type { Detection } from "@/hooks/useObjectDetection";

interface CameraFeedProps {
  videoRef: RefObject<HTMLVideoElement>;
  isActive: boolean;
  error: string | null;
  detections: Detection[];
  isScanning?: boolean;
  isFrozen?: boolean;
  frozenFrame?: string | null;
  frozenDimensions?: { w: number; h: number } | null;
  modelReady?: boolean;
}

const PRIORITY_COLORS: Record<number, string> = {
  1: "hsl(0, 70%, 52%)",
  2: "hsl(38, 90%, 52%)",
  3: "hsl(35, 95%, 55%)",
  4: "hsl(220, 10%, 50%)",
};

export function CameraFeed({
  videoRef,
  isActive,
  error,
  detections,
  isScanning,
  isFrozen = false,
  frozenFrame,
  frozenDimensions,
  modelReady = false,
}: CameraFeedProps) {
  const video = videoRef.current;
  const videoWidth = isFrozen && frozenDimensions ? frozenDimensions.w : (video?.videoWidth || 640);
  const videoHeight = isFrozen && frozenDimensions ? frozenDimensions.h : (video?.videoHeight || 480);
  const showVideo = isActive && !isFrozen;

  return (
    <div
      className={`relative w-full aspect-[4/3] overflow-hidden rounded-lg border transition-colors ${
        isScanning && (isActive || isFrozen)
          ? "border-primary/40 scan-active bg-secondary/30"
          : "border-border bg-secondary/40"
      }`}
    >
      {showVideo && (
        <>
          <div className="absolute top-2 left-2 w-5 h-5 border-t-2 border-l-2 border-primary/60 rounded-tl z-10 pointer-events-none" />
          <div className="absolute top-2 right-2 w-5 h-5 border-t-2 border-r-2 border-primary/60 rounded-tr z-10 pointer-events-none" />
          <div className="absolute bottom-2 left-2 w-5 h-5 border-b-2 border-l-2 border-primary/60 rounded-bl z-10 pointer-events-none" />
          <div className="absolute bottom-2 right-2 w-5 h-5 border-b-2 border-r-2 border-primary/60 rounded-br z-10 pointer-events-none" />
        </>
      )}

      {isScanning && (isActive || isFrozen) && (
        <div className="absolute inset-0 scanline-effect z-10 pointer-events-none" />
      )}

      {isFrozen && frozenFrame ? (
        <img
          src={frozenFrame}
          alt="Frozen frame"
          className="w-full h-full object-cover block"
        />
      ) : (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`w-full h-full object-cover ${showVideo ? "block" : "hidden"}`}
          aria-label="Live camera feed"
        />
      )}

      {(showVideo || isFrozen) ? (
        <>
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-20"
            viewBox={`0 0 ${videoWidth} ${videoHeight}`}
            preserveAspectRatio="xMidYMid slice"
          >
            {detections.map((d, i) => {
              const [x, y, w, h] = d.bbox;
              const color = PRIORITY_COLORS[d.priority] ?? PRIORITY_COLORS[3];
              return (
                <g key={`${d.label}-${d.bbox[0]}-${d.bbox[1]}`}>
                  <rect
                    x={x - 1}
                    y={y - 1}
                    width={w + 2}
                    height={h + 2}
                    fill="none"
                    stroke={color}
                    strokeWidth={1}
                    rx={4}
                    opacity={0.25}
                  />
                  <rect
                    x={x}
                    y={y}
                    width={w}
                    height={h}
                    fill="none"
                    stroke={color}
                    strokeWidth={2}
                    rx={4}
                    strokeDasharray="6 4"
                  />
                  <rect
                    x={x}
                    y={Math.max(0, y - 22)}
                    width={Math.max(w, 72)}
                    height={20}
                    fill={color}
                    rx={4}
                    opacity={0.95}
                  />
                  <text
                    x={x + 5}
                    y={Math.max(0, y - 22) + 14}
                    fill="white"
                    fontSize={11}
                    fontWeight={600}
                    fontFamily="'Outfit', system-ui, sans-serif"
                  >
                    {d.label} {Math.round(d.confidence)}%
                  </text>
                </g>
              );
            })}
          </svg>

          {detections.length > 0 && (
            <div className="absolute top-2 right-10 z-30 flex items-center gap-1.5 px-2 py-0.5 rounded bg-background/90 border border-border">
              <span className="w-1 h-1 rounded-full bg-primary" />
              <span className="text-[11px] font-mono font-medium">{detections.length}</span>
            </div>
          )}
        </>
      ) : (
        <div className="flex flex-col items-center justify-center h-full gap-5 px-6 text-center">
          {!modelReady ? (
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
              <div>
                <p className="text-base font-semibold text-foreground mb-1.5">
                  Hi, I'm Vision Assist!
                </p>
                <p className="text-sm text-muted-foreground">
                  Please wait while I get set up
                  <span className="inline-flex">
                    <span className="animate-pulse">.</span>
                    <span className="animate-pulse" style={{ animationDelay: "0.2s" }}>.</span>
                    <span className="animate-pulse" style={{ animationDelay: "0.4s" }}>.</span>
                  </span>
                </p>
              </div>
            </div>
          ) : error ? (
            <>
              <div className="w-14 h-14 rounded-lg bg-destructive/10 flex items-center justify-center">
                <CameraOff className="w-7 h-7 text-destructive" aria-hidden="true" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground mb-1">Oops, I can't see!</p>
                <p className="text-[11px] text-muted-foreground" role="alert">
                  {error}
                </p>
                <p className="text-[10px] text-muted-foreground/80 mt-2">
                  Please allow camera access and try again
                </p>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20">
                <Camera className="w-7 h-7 text-primary" aria-hidden="true" />
              </div>
              <div>
                <p className="text-base font-semibold text-foreground mb-1.5">
                  I'm ready!
                </p>
                <p className="text-sm text-muted-foreground mb-3">
                  When you're ready, press Start Scan or Space and I'll begin scanning your surroundings
                </p>
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  <kbd className="px-2 py-1 rounded bg-muted border border-border text-[10px] font-mono">Start Scan</kbd>
                  <span className="text-muted-foreground/60 text-[10px]">or</span>
                  <kbd className="px-2 py-1 rounded bg-muted border border-border text-[10px] font-mono">Space</kbd>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
