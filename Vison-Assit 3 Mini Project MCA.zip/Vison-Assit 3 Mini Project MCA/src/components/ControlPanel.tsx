import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Square, Volume2, Mic, MicOff, Gauge, Scan, Camera, ImageIcon } from "lucide-react";
import type { ModelType } from "@/hooks/useObjectDetection";

interface ControlPanelProps {
  isScanning: boolean;
  onToggleScan: () => void;
  confidence: number;
  onConfidenceChange: (value: number) => void;
  volume: number;
  onVolumeChange: (value: number) => void;
  speechRate: number;
  onSpeechRateChange: (value: number) => void;
  isVoiceActive: boolean;
  onToggleVoice: () => void;
  voiceSupported: boolean;
  modelType: ModelType;
  onModelTypeChange: (v: ModelType) => void;
  isFrozen: boolean;
  onToggleFreeze: () => void;
  canFreeze: boolean;
}

export function ControlPanel({
  isScanning,
  onToggleScan,
  confidence,
  onConfidenceChange,
  volume,
  onVolumeChange,
  speechRate,
  onSpeechRateChange,
  isVoiceActive,
  onToggleVoice,
  voiceSupported,
  modelType,
  onModelTypeChange,
  isFrozen,
  onToggleFreeze,
  canFreeze,
}: ControlPanelProps) {
  return (
    <div className="space-y-4">
      <Button
        onClick={onToggleScan}
        className={`w-full h-11 text-sm font-semibold transition-all ${
          isScanning
            ? "bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            : "bg-primary hover:bg-primary/90 text-primary-foreground"
        }`}
        aria-label={isScanning ? "Stop scanning" : "Start scanning"}
      >
        {isScanning ? (
          <>
            <Square className="w-4 h-4 mr-2" aria-hidden="true" />
            Stop
          </>
        ) : (
          <>
            <Scan className="w-4 h-4 mr-2" aria-hidden="true" />
            Start Scan
          </>
        )}
      </Button>

      {canFreeze && (
        <Button
          variant="secondary"
          size="sm"
          onClick={onToggleFreeze}
          className={`w-full ${isFrozen ? "border-primary/40 bg-primary/5" : ""}`}
          aria-label={isFrozen ? "Unfreeze frame" : "Freeze frame (F)"}
        >
          {isFrozen ? (
            <>
              <ImageIcon className="w-3.5 h-3.5 mr-2" aria-hidden="true" />
              Unfreeze
            </>
          ) : (
            <>
              <Camera className="w-3.5 h-3.5 mr-2" aria-hidden="true" />
              Freeze (F)
            </>
          )}
        </Button>
      )}

      <div className="flex gap-2">
        <Button
          variant={modelType === "accurate" ? "default" : "secondary"}
          size="sm"
          className="flex-1 h-8 text-xs"
          onClick={() => onModelTypeChange("accurate")}
        >
          Accurate
        </Button>
        <Button
          variant={modelType === "fast" ? "default" : "secondary"}
          size="sm"
          className="flex-1 h-8 text-xs"
          onClick={() => onModelTypeChange("fast")}
        >
          Fast
        </Button>
      </div>

      <div className="space-y-2 p-3 rounded bg-muted/50 border border-border">
        <div className="flex justify-between">
          <label className="text-[11px] font-medium text-muted-foreground flex items-center gap-1.5">
            <Gauge className="w-3 h-3" aria-hidden="true" />
            Confidence
          </label>
          <span className="text-[11px] font-mono font-semibold text-primary">{confidence}%</span>
        </div>
        <Slider
          value={[confidence]}
          onValueChange={(v) => onConfidenceChange(v[0])}
          min={55}
          max={95}
          step={1}
          aria-label="Confidence threshold"
        />
      </div>

      <div className="space-y-2 p-3 rounded bg-muted/50 border border-border">
        <div className="flex justify-between">
          <label className="text-[11px] font-medium text-muted-foreground flex items-center gap-1.5">
            <Volume2 className="w-3 h-3" aria-hidden="true" />
            Volume
          </label>
          <span className="text-[11px] font-mono font-semibold text-primary">{Math.round(volume * 100)}%</span>
        </div>
        <Slider
          value={[volume * 100]}
          onValueChange={(v) => onVolumeChange(v[0] / 100)}
          min={0}
          max={100}
          step={5}
          aria-label="Audio volume"
        />
      </div>

      <div className="space-y-2 p-3 rounded bg-muted/50 border border-border">
        <div className="flex justify-between">
          <label className="text-[11px] font-medium text-muted-foreground">
            Speech speed
          </label>
          <span className="text-[11px] font-mono font-semibold text-primary">
            {speechRate < 0.4 ? "Slower" : speechRate > 0.6 ? "Faster" : "Normal"}
          </span>
        </div>
        <Slider
          value={[speechRate * 100]}
          onValueChange={(v) => onSpeechRateChange(v[0] / 100)}
          min={0}
          max={100}
          step={10}
          aria-label="Speech rate"
        />
      </div>

      {voiceSupported && (
        <Button
          variant="secondary"
          size="sm"
          className={`w-full ${isVoiceActive ? "border-primary/40 bg-primary/5" : ""}`}
          onClick={onToggleVoice}
          aria-label={isVoiceActive ? "Disable voice commands" : "Enable voice commands"}
        >
          {isVoiceActive ? (
            <>
              <Mic className="w-3.5 h-3.5 mr-2 text-primary" aria-hidden="true" />
              <span className="text-primary">Voice on</span>
            </>
          ) : (
            <>
              <MicOff className="w-3.5 h-3.5 mr-2" aria-hidden="true" />
              Voice commands
            </>
          )}
        </Button>
      )}
    </div>
  );
}
