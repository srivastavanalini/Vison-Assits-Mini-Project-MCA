import type { Detection } from "@/hooks/useObjectDetection";
import { Eye, Loader2, Target } from "lucide-react";

interface DetectionPanelProps {
  detections: Detection[];
  isProcessing: boolean;
  isScanning: boolean;
  isFrozen?: boolean;
}

function getPriorityLabel(priority: number): string {
  if (priority <= 1) return "High";
  if (priority <= 2) return "Med";
  return "Low";
}

function getPriorityStyles(priority: number): string {
  if (priority <= 1) return "bg-destructive/10 text-destructive border-destructive/20";
  if (priority <= 2) return "bg-warning/10 text-warning border-warning/20";
  return "bg-muted text-muted-foreground border-border";
}

export function DetectionPanel({
  detections,
  isProcessing,
  isScanning,
  isFrozen = false,
}: DetectionPanelProps) {
  return (
    <div className="flex flex-col h-full" role="log" aria-label="Detected objects" aria-live="polite">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          Detections
        </h2>
        {isProcessing && (
          <div className="flex items-center gap-1.5 text-primary">
            <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" />
            <span className="text-[10px] font-medium">Analyzing</span>
          </div>
        )}
      </div>

      {!isScanning && !isFrozen ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-3 px-4">
            <div className="w-11 h-11 mx-auto rounded-lg bg-primary/10 flex items-center justify-center border border-primary/20">
              <Target className="w-5 h-5 text-primary/60" aria-hidden="true" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">I'm waiting for you</p>
              <p className="text-[10px] text-muted-foreground/70 mt-0.5">
                When you start scanning, I'll tell you what I see right here
              </p>
            </div>
          </div>
        </div>
      ) : detections.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-3 px-4">
            <div className="w-11 h-11 mx-auto rounded-lg bg-muted flex items-center justify-center border border-border">
              <Eye className="w-5 h-5 text-muted-foreground/40 animate-pulse" aria-hidden="true" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">
                {isProcessing ? "Looking around…" : "Nothing spotted yet"}
              </p>
              <p className="text-[10px] text-muted-foreground/70 mt-0.5">
                {isProcessing ? "Give me a moment to analyze" : "Point your camera at something — I'll let you know when I see it"}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <ul className="space-y-1.5 flex-1 overflow-y-auto pr-1 min-h-0">
          {detections.map((d, i) => (
            <li
              key={`${d.label}-${d.bbox[0]}-${d.bbox[1]}`}
              className="flex items-center justify-between py-2.5 px-3 rounded border border-border bg-muted/30 hover:border-primary/20 transition-colors"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="text-sm font-medium text-foreground truncate">{d.label}</span>
                <span
                  className={`shrink-0 text-[9px] font-semibold uppercase px-1.5 py-0.5 rounded border ${getPriorityStyles(d.priority)}`}
                >
                  {getPriorityLabel(d.priority)}
                </span>
              </div>
              <span className="text-[11px] font-mono font-semibold text-primary shrink-0 ml-2">
                {d.confidence.toFixed(1)}%
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
