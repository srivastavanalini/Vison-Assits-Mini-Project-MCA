import { Volume2, Mic, Activity, ImageIcon } from "lucide-react";

interface StatusBarProps {
  isScanning: boolean;
  isSpeaking: boolean;
  detectionCount: number;
  isVoiceListening: boolean;
  isFrozen?: boolean;
}

export function StatusBar({
  isScanning,
  isSpeaking,
  detectionCount,
  isVoiceListening,
  isFrozen = false,
}: StatusBarProps) {
  return (
    <div
      className="flex items-center justify-between px-4 py-2.5 panel rounded-lg text-[11px]"
      role="status"
      aria-live="polite"
    >
      <div className="flex items-center gap-4">
        <span className="flex items-center gap-2">
          <span
            className={`w-2 h-2 rounded-full transition-colors ${
              isScanning ? "bg-success" : "bg-muted-foreground/40"
            }`}
          />
          <span className={`font-medium ${isScanning ? "text-success" : "text-muted-foreground"}`}>
            {isScanning ? "Scanning" : "Ready"}
          </span>
        </span>

        {isFrozen && (
          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-primary/10 border border-primary/20 text-primary font-medium">
            <ImageIcon className="w-3 h-3" />
            Frozen
          </span>
        )}

        {isScanning && (
          <>
            <span className="w-px h-3 bg-border" />
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <Activity className="w-3 h-3" />
              {detectionCount} object{detectionCount !== 1 ? "s" : ""}
            </span>
          </>
        )}
      </div>

      <div className="flex items-center gap-2">
        {isVoiceListening && (
          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-primary/10 border border-primary/20 text-primary font-medium">
            <Mic className="w-3 h-3" />
            Listen
          </span>
        )}
        {isSpeaking && (
          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-accent/10 border border-accent/20 text-accent font-medium">
            <Volume2 className="w-3 h-3" />
            Speaking
          </span>
        )}
      </div>
    </div>
  );
}
