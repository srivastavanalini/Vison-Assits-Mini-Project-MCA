import { useEffect, useState, useCallback, type CSSProperties, type RefObject } from "react";

export type BoxDetection = {
  label: string;
  confidence: number;
  bbox: [number, number, number, number];
};

function computeBoxes(
  video: HTMLVideoElement,
  detections: BoxDetection[]
): Array<{ key: string; label: string; style: CSSProperties }> {
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  if (!vw || !vh) return [];

  const rect = video.getBoundingClientRect();
  const elW = rect.width;
  const elH = rect.height;
  const videoAspect = vw / vh;
  const elAspect = elW / elH;

  let drawW: number;
  let drawH: number;
  let offX: number;
  let offY: number;

  if (elAspect > videoAspect) {
    drawH = elH;
    drawW = drawH * videoAspect;
    offX = (elW - drawW) / 2;
    offY = 0;
  } else {
    drawW = elW;
    drawH = drawW / videoAspect;
    offX = 0;
    offY = (elH - drawH) / 2;
  }

  return detections.map((d, i) => {
    const [x, y, w, h] = d.bbox;
    const normalized = x <= 1 && y <= 1 && w <= 1 && h <= 1;
    const left = offX + (normalized ? x * drawW : (x / vw) * drawW);
    const top = offY + (normalized ? y * drawH : (y / vh) * drawH);
    const width = normalized ? w * drawW : (w / vw) * drawW;
    const height = normalized ? h * drawH : (h / vh) * drawH;
    return {
      key: `${d.label}-${i}-${Math.round(x)}-${Math.round(y)}`,
      label: `${d.label} ${Math.round(d.confidence)}%`,
      style: {
        position: "absolute" as const,
        left,
        top,
        width,
        height,
      },
    };
  });
}

export function DetectionOverlay({
  videoRef,
  detections,
}: {
  videoRef: RefObject<HTMLVideoElement | null>;
  detections: BoxDetection[];
}) {
  const [items, setItems] = useState<Array<{ key: string; label: string; style: CSSProperties }>>(
    []
  );

  const update = useCallback(() => {
    const video = videoRef.current;
    if (!video || detections.length === 0) {
      setItems([]);
      return;
    }
    setItems(computeBoxes(video, detections));
  }, [videoRef, detections]);

  useEffect(() => {
    update();
    const v = videoRef.current;
    const ro = new ResizeObserver(() => update());
    if (v) ro.observe(v);
    const id = window.requestAnimationFrame(update);
    return () => {
      ro.disconnect();
      window.cancelAnimationFrame(id);
    };
  }, [update, videoRef]);

  if (items.length === 0) return null;

  return (
    <div className="pointer-events-none absolute inset-0" aria-hidden>
      {items.map((item) => (
        <div
          key={item.key}
          className="rounded-[4px] border-2 border-[hsl(var(--accent))] bg-[hsl(var(--accent)/0.12)] shadow-[0_0_0_1px_rgba(255,255,255,0.35)_inset]"
          style={item.style}
        >
          <span className="absolute -top-6 left-0 max-w-[min(100%,12rem)] truncate rounded bg-neutral-900/85 px-1.5 py-0.5 text-[10px] font-medium text-white">
            {item.label}
          </span>
        </div>
      ))}
    </div>
  );
}
