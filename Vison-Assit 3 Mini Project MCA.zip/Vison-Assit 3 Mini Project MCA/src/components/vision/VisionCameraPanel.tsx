import type { RefObject } from "react";
import { DetectionOverlay, type BoxDetection } from "@/components/vision/DetectionOverlay";

export function VisionCameraPanel({
  videoRef,
  isActive,
  error,
  isScanning,
  boxDetections,
  immersive = false,
  className = "",
}: {
  videoRef: RefObject<HTMLVideoElement>;
  isActive: boolean;
  error: string | null;
  isScanning: boolean;
  boxDetections?: BoxDetection[];
  immersive?: boolean;
  className?: string;
}) {
  const showBoxes = Boolean(isActive && isScanning && boxDetections && boxDetections.length > 0);

  return (
    <section
      className={`${
        immersive ? "relative h-full min-h-[100svh]" : "surface-card flex flex-col gap-4 p-4 sm:p-5"
      } ${className}`}
    >
      {!immersive && (
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-500">
            Live camera
          </h2>
          {isScanning && isActive && (
            <span className="inline-flex items-center gap-1 text-xs text-neutral-500">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />
              Live
            </span>
          )}
        </div>
      )}
      <div
        className={`relative overflow-hidden ${
          immersive
            ? "h-full min-h-[100svh] bg-[radial-gradient(circle_at_top,_rgba(56,189,248,0.12),_rgba(2,6,23,0.98)_34%,_rgba(0,0,0,1)_100%)]"
            : `rounded-[12px] bg-black ring-1 ring-neutral-200/80 transition-all duration-300 ${
                isScanning
                  ? "shadow-[0_8px_28px_rgba(59,92,158,0.10)] ring-accent/35"
                  : "shadow-[0_2px_6px_rgba(15,23,42,0.05)]"
              }`
        }`}
      >
        <video
          ref={videoRef}
          className={`w-full object-contain ${immersive ? "h-full min-h-[100svh]" : "aspect-video"}`}
          playsInline
          muted
          autoPlay
        />
        {showBoxes && (
          <DetectionOverlay videoRef={videoRef} detections={boxDetections!} />
        )}
        {immersive && isScanning && isActive && (
          <div className="pointer-events-none absolute right-4 top-4 inline-flex items-center gap-2 rounded-full bg-black/45 px-3 py-1.5 text-xs text-white ring-1 ring-white/12 backdrop-blur">
            <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
            Live
          </div>
        )}
        {!isActive && (
          <div
            className={`absolute inset-0 flex items-center justify-center px-6 text-center ${
              immersive ? "bg-black/35 backdrop-blur-[2px]" : "bg-neutral-50/95"
            }`}
          >
            <p
              className={`max-w-sm text-sm leading-relaxed ${
                immersive ? "text-white/80" : "text-neutral-500"
              }`}
            >
              {error ?? "Start detection to enable the camera."}
            </p>
          </div>
        )}
        {isActive && error && (
          <div
            className={`absolute inset-x-3 bottom-3 rounded-lg px-3 py-2 text-sm shadow-sm backdrop-blur ${
              immersive
                ? "bg-rose-500/14 text-rose-100 ring-1 ring-rose-300/25"
                : "bg-white/95 text-rose-700 ring-1 ring-rose-200"
            }`}
          >
            {error}
          </div>
        )}
      </div>
    </section>
  );
}
