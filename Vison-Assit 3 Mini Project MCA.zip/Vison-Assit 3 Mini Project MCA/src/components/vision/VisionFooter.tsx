import { Volume2 } from "lucide-react";

export type VisionMode = "aws" | "local";

export function VisionFooter({
  systemMessage,
  audioPlaying,
  backendOk,
  backendDetail,
  awsRegion,
  credentialsSource,
  mode,
  embedded = false,
  className = "",
}: {
  systemMessage: string;
  audioPlaying: boolean;
  backendOk: boolean | null;
  backendDetail?: string | null;
  awsRegion?: string | null;
  credentialsSource?: string | null;
  mode: VisionMode;
  embedded?: boolean;
  className?: string;
}) {
  const content = (
    <>
      <p className={embedded ? "text-sm text-white/78" : "text-sm text-neutral-600"}>
        {systemMessage}
      </p>
      <div
        className={`flex flex-wrap items-center gap-2 text-xs ${
          embedded ? "text-white/65" : "text-neutral-500"
        }`}
      >
        <span
          className={`inline-flex items-center gap-1.5 rounded-md px-2 py-1 ${
            audioPlaying
              ? embedded
                ? "bg-sky-400/15 text-sky-100"
                : "bg-accent-soft text-accent-soft-foreground"
              : embedded
                ? "bg-white/10 text-white/75"
                : "bg-white text-neutral-500"
          } ring-1 ${embedded ? "ring-white/10" : "ring-neutral-200/80"}`}
        >
          <Volume2 className="h-3.5 w-3.5 opacity-70" aria-hidden />
          {audioPlaying ? "Audio playing" : "Audio idle"}
        </span>
        {mode === "local" && (
          <span
            className={`rounded-md px-2 py-1 ring-1 ${
              embedded
                ? "bg-white/10 text-white/75 ring-white/10"
                : "bg-neutral-100 text-neutral-700 ring-neutral-200/80"
            }`}
          >
            On-device scan
          </span>
        )}
        {mode === "aws" && backendOk !== null && (
          <span
            className={`rounded-md px-2 py-1 ring-1 ${
              embedded ? "bg-white/10 ring-white/10" : "bg-white ring-neutral-200/80"
            }`}
          >
            Service {backendOk ? "connected" : "unreachable"}
          </span>
        )}
        {mode === "aws" && backendDetail && (
          <span
            className={`rounded-md px-2 py-1 ring-1 ${
              embedded
                ? "bg-white/10 text-white/75 ring-white/10"
                : "bg-neutral-100 text-neutral-700 ring-neutral-200/80"
            }`}
          >
            {backendDetail}
          </span>
        )}
        {mode === "aws" && awsRegion && (
          <span
            className={`rounded-md px-2 py-1 ring-1 ${
              embedded ? "bg-white/10 ring-white/10" : "bg-white ring-neutral-200/80"
            }`}
          >
            Region {awsRegion}
          </span>
        )}
        {mode === "aws" && credentialsSource && (
          <span
            className={`rounded-md px-2 py-1 ring-1 ${
              embedded ? "bg-white/10 ring-white/10" : "bg-white ring-neutral-200/80"
            }`}
          >
            Creds {credentialsSource}
          </span>
        )}
      </div>
    </>
  );

  if (embedded) {
    return (
      <div
        className={`flex flex-col gap-3 rounded-[22px] bg-black/45 px-4 py-4 backdrop-blur-xl ring-1 ring-white/10 ${className}`}
      >
        {content}
      </div>
    );
  }

  return (
    <footer className={`border-t border-neutral-200/80 bg-white/70 ${className}`}>
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
        {content}
      </div>
    </footer>
  );
}
