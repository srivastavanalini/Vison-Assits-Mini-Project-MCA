type AppStatus = "idle" | "detecting" | "active";

const copy: Record<AppStatus, { label: string; className: string }> = {
  idle: {
    label: "Idle",
    className: "bg-neutral-200 text-neutral-700",
  },
  detecting: {
    label: "Detecting",
    className: "bg-amber-100 text-amber-900",
  },
  active: {
    label: "Active",
    className: "bg-emerald-100 text-emerald-900",
  },
};

export function VisionNav({
  status,
  awsReady,
  compact = false,
  className = "",
}: {
  status: AppStatus;
  awsReady?: boolean | null;
  compact?: boolean;
  className?: string;
}) {
  const cfg = copy[status];
  const statusChips = (
    <div className="flex items-center gap-2 rounded-full bg-white/10 p-1 text-white/80 ring-1 ring-white/15 backdrop-blur">
      {awsReady === false && (
        <span className="rounded-full bg-amber-300/20 px-2.5 py-1 text-xs font-medium text-amber-100">
          AWS setup needed
        </span>
      )}
      <span className="text-xs text-white/60">Status</span>
      <span
        className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${cfg.className}`}
      >
        {cfg.label}
      </span>
    </div>
  );

  if (compact) {
    return (
      <div
        className={`flex items-center justify-between gap-4 rounded-[22px] bg-black/45 px-4 py-3 text-white ring-1 ring-white/12 backdrop-blur-xl ${className}`}
      >
        <div className="flex items-center gap-3">
          <span className="inline-block h-2 w-2 rounded-full bg-sky-300" />
          <div className="space-y-0.5">
            <div className="text-sm font-semibold tracking-tight text-white">
              Real-Time Vision Assist
            </div>
            <div className="text-xs text-white/60">Live scene understanding</div>
          </div>
        </div>
        {statusChips}
      </div>
    );
  }

  return (
    <header
      className={`sticky top-0 z-40 border-b border-neutral-200/80 bg-white/85 backdrop-blur-lg ${className}`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <span className="inline-block h-2 w-2 rounded-full bg-accent/80" />
          <span className="text-sm font-semibold tracking-tight text-neutral-900">
            Real-Time Vision Assist
          </span>
          <span className="hidden text-xs text-neutral-500 sm:inline">
            Live scene understanding
          </span>
        </div>
        <div className="flex items-center gap-2 rounded-full bg-neutral-100/80 p-1 ring-1 ring-neutral-200/80">
          {awsReady === false && (
            <span className="rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-900">
              AWS setup needed
            </span>
          )}
          <span className="text-xs text-neutral-500">Status</span>
          <span
            className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${cfg.className}`}
          >
            {cfg.label}
          </span>
        </div>
      </div>
    </header>
  );
}
