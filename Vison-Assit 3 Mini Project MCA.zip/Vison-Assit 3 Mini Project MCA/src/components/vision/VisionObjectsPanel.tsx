import { Circle } from "lucide-react";
import type { VisionLabel } from "@/lib/visionApi";

export function VisionObjectsPanel({
  labels,
  isProcessing,
  waitingForModel,
  error,
  overlay = false,
  className = "",
}: {
  labels: VisionLabel[];
  isProcessing: boolean;
  waitingForModel?: boolean;
  error?: string | null;
  overlay?: boolean;
  className?: string;
}) {
  return (
    <section
      className={`flex min-h-0 flex-1 flex-col gap-4 ${
        overlay
          ? "rounded-[26px] bg-black/48 p-4 text-white shadow-[0_18px_48px_rgba(0,0,0,0.28)] ring-1 ring-white/10 backdrop-blur-xl"
          : "surface-card p-4 sm:p-5"
      } ${className}`}
    >
      <div className="flex items-center justify-between">
        <h2
          className={`text-xs font-semibold uppercase tracking-[0.14em] ${
            overlay ? "text-white/60" : "text-neutral-500"
          }`}
        >
          Detected objects
        </h2>
        <span
          className={`rounded-full px-2.5 py-1 text-xs tabular-nums ${
            overlay
              ? "bg-white/10 text-white/70 ring-1 ring-white/10"
              : "bg-neutral-100 text-neutral-500 ring-1 ring-neutral-200/70"
          }`}
        >
          {labels.length} {labels.length === 1 ? "item" : "items"}
        </span>
      </div>
      <div
        className={`overflow-hidden rounded-[18px] ${
          overlay
            ? "min-h-[240px] bg-black/22 ring-1 ring-white/10"
            : "min-h-[320px] bg-white ring-1 ring-neutral-200/80"
        }`}
      >
        <ul
          className={`overflow-y-auto ${
            overlay
              ? "max-h-[min(44vh,32rem)] divide-y divide-white/10"
              : "max-h-[min(420px,60vh)] divide-y divide-neutral-100"
          }`}
        >
          {waitingForModel && labels.length === 0 && (
            <li className={`px-4 py-8 text-center text-sm ${overlay ? "text-white/70" : "text-neutral-500"}`}>
              Loading the on-device model. This may take a moment the first time.
            </li>
          )}
          {!waitingForModel && error && labels.length === 0 && (
            <li className={`px-4 py-8 text-center text-sm ${overlay ? "text-rose-200" : "text-rose-700"}`}>
              {error}
            </li>
          )}
          {!waitingForModel && !error && labels.length === 0 && !isProcessing && (
            <li className={`px-4 py-8 text-center text-sm ${overlay ? "text-white/70" : "text-neutral-500"}`}>
              No objects detected yet. Point the camera at your surroundings.
            </li>
          )}
          {!waitingForModel && !error && isProcessing && labels.length === 0 && (
            <li className={`px-4 py-8 text-center text-sm ${overlay ? "text-white/70" : "text-neutral-500"}`}>
              Analyzing the current frame.
            </li>
          )}
          {labels.map((label) => (
            <li
              key={label.name}
              className={`flex items-center gap-3 px-4 py-3.5 transition-colors duration-200 ${
                overlay ? "hover:bg-white/6" : "hover:bg-neutral-50/80"
              }`}
            >
              <Circle
                className={`h-2 w-2 shrink-0 ${overlay ? "text-sky-300" : "text-accent/90"}`}
                strokeWidth={2}
                aria-hidden
              />
              <span
                className={`min-w-0 flex-1 truncate text-sm font-medium ${
                  overlay ? "text-white" : "text-neutral-900"
                }`}
              >
                {label.name}
              </span>
              <span
                className={`shrink-0 rounded-md px-2 py-1 text-xs tabular-nums ${
                  overlay ? "bg-white/10 text-white/75" : "bg-neutral-100 text-neutral-600"
                }`}
              >
                {label.confidence % 1 === 0
                  ? `${Math.round(label.confidence)}%`
                  : `${label.confidence.toFixed(1)}%`}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
