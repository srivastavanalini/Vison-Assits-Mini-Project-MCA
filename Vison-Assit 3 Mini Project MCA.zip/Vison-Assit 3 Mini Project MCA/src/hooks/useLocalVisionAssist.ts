import type { RefObject } from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { VisionLabel } from "@/lib/visionApi";
import { useObjectDetection, type Detection } from "@/hooks/useObjectDetection";

const FRAME_INTERVAL_MS = 900;
const LOCAL_CONFIDENCE_MIN = 50;
const SPEAK_COOLDOWN_MS = 6000;

type Status = "idle" | "detecting" | "active";

function humanizeClass(name: string): string {
  return name.toLowerCase().replace(/_/g, " ");
}

function buildSpeechPhrase(labels: string[]): string {
  if (labels.length === 0) return "";
  const raw = labels.map(humanizeClass);
  if (raw.length === 1) return `I see a ${raw[0]}.`;
  if (raw.length === 2) return `I see a ${raw[0]} and a ${raw[1]}.`;
  if (raw.length === 3) {
    return `I see a ${raw[0]}, a ${raw[1]}, and a ${raw[2]}.`;
  }
  return `I see ${raw.slice(0, 3).map((x) => `a ${x}`).join(", ")}, and more.`;
}

function speakBrowser(
  text: string,
  handlers: {
    onStart?: () => void;
    onEnd: () => void;
  }
): void {
  if (!text.trim() || typeof window === "undefined" || !window.speechSynthesis) {
    handlers.onEnd();
    return;
  }

  const u = new SpeechSynthesisUtterance(text);
  u.rate = 0.92;
  u.pitch = 1;
  u.onstart = () => handlers.onStart?.();
  u.onend = handlers.onEnd;
  u.onerror = handlers.onEnd;
  window.speechSynthesis.speak(u);
}

export function useLocalVisionAssist(
  videoRef: RefObject<HTMLVideoElement | null>,
  isScanning: boolean,
  loadModel: boolean
) {
  const { processFrame, modelReady, loadFailed, isProcessing } = useObjectDetection(
    "accurate",
    loadModel
  );

  const [labels, setLabels] = useState<VisionLabel[]>([]);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [systemMessage, setSystemMessage] = useState(
    "On-device mode: no API keys. Uses your browser and system speech."
  );
  const [lastSpoken, setLastSpoken] = useState<string | null>(null);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [busy, setBusy] = useState(false);

  const lastSpokenAtRef = useRef<Map<string, number>>(new Map());
  const speakingRef = useRef(false);
  const pendingSpeechRef = useRef<{ phrase: string; names: string[] } | null>(null);
  const isScanningRef = useRef(isScanning);
  const mounted = useRef(true);

  useEffect(() => {
    isScanningRef.current = isScanning;
  }, [isScanning]);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      window.speechSynthesis?.cancel();
    };
  }, []);

  useEffect(() => {
    if (!loadModel) return;
    if (loadFailed) {
      setSystemMessage(
        "Could not load the on-device model. Check your connection for the first download."
      );
      return;
    }
    if (!modelReady) {
      setSystemMessage("Loading vision model (first visit downloads ~20MB)…");
    }
  }, [loadModel, loadFailed, modelReady]);

  const speakPhrase = useCallback((phrase: string, names: string[]) => {
    const spokenAt = Date.now();
    for (const name of names) {
      lastSpokenAtRef.current.set(name.toLowerCase(), spokenAt);
    }

    setLastSpoken(phrase);
    setSystemMessage("Speaking with your browser voice.");

    speakBrowser(phrase, {
      onStart: () => {
        speakingRef.current = true;
        if (mounted.current) setAudioPlaying(true);
      },
      onEnd: () => {
        speakingRef.current = false;
        if (mounted.current) setAudioPlaying(false);

        const pending = pendingSpeechRef.current;
        pendingSpeechRef.current = null;

        if (!pending || !mounted.current || !isScanningRef.current) return;
        speakPhrase(pending.phrase, pending.names);
      },
    });
  }, []);

  const runOnce = useCallback(async () => {
    const video = videoRef.current;
    if (!video || !modelReady) return;

    if (video.readyState < 2) return;

    setBusy(true);
    try {
      const result = await processFrame(video, LOCAL_CONFIDENCE_MIN);
      if (!mounted.current) return;

      setDetections(result.all);

      const next = result.all.map((d) => ({
        name: d.label,
        confidence: Math.round(d.confidence * 10) / 10,
      }));
      setLabels(next);

      const now = Date.now();
      const seen = new Set<string>();
      const uniqueForSpeech: Detection[] = [];
      for (const d of [...result.all].sort((a, b) => a.priority - b.priority || b.confidence - a.confidence)) {
        const key = d.label.toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        uniqueForSpeech.push(d);
      }

      const toSay: string[] = [];
      for (const d of uniqueForSpeech.slice(0, 4)) {
        const key = d.label.toLowerCase();
        const last = lastSpokenAtRef.current.get(key);
        if (last !== undefined && now - last < SPEAK_COOLDOWN_MS) continue;
        toSay.push(d.label);
      }

      if (toSay.length > 0) {
        const phrase = buildSpeechPhrase(toSay);
        if (speakingRef.current) {
          pendingSpeechRef.current = { phrase, names: toSay };
          setSystemMessage(
            `Tracking ${result.all.length} object${result.all.length === 1 ? "" : "s"}. Finishing the current announcement first.`
          );
        } else {
          speakPhrase(phrase, toSay);
        }
      } else if (result.all.length === 0) {
        setSystemMessage(
          `Scanning… (showing objects above ${LOCAL_CONFIDENCE_MIN}% confidence)`
        );
      } else {
        setSystemMessage(
          `Tracking ${result.all.length} object${result.all.length === 1 ? "" : "s"}. Next announcement after cooldown.`
        );
      }
    } finally {
      if (mounted.current) setBusy(false);
    }
  }, [videoRef, modelReady, processFrame, speakPhrase]);

  useEffect(() => {
    if (!isScanning) {
      setLabels([]);
      setDetections([]);
      setLastSpoken(null);
      setAudioPlaying(false);
      lastSpokenAtRef.current.clear();
      pendingSpeechRef.current = null;
      speakingRef.current = false;
      setSystemMessage(
        loadModel
          ? "On-device mode ready. No AWS or backend required."
          : "Camera idle."
      );
      window.speechSynthesis?.cancel();
      return;
    }

    if (!loadModel || loadFailed || !modelReady) {
      return;
    }

    let cancelled = false;
    const tick = async () => {
      if (cancelled) return;
      await runOnce();
    };

    tick();
    const id = window.setInterval(tick, FRAME_INTERVAL_MS);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [isScanning, loadModel, loadFailed, modelReady, runOnce]);

  const status: Status = !isScanning
    ? "idle"
    : !modelReady && !loadFailed
      ? "detecting"
      : busy || isProcessing
        ? "detecting"
        : "active";

  return {
    labels,
    detections,
    isProcessing: busy || isProcessing,
    systemMessage,
    lastSpoken,
    audioPlaying,
    error: loadFailed ? "Local model failed to load." : null,
    status,
    modelReady,
    loadFailed,
  };
}
