import { useState, useCallback, useRef, useEffect } from "react";
import * as cocoSsd from "@tensorflow-models/coco-ssd";
import * as tf from "@tensorflow/tfjs";

export interface Detection {
  label: string;
  confidence: number;
  priority: number;
  timestamp: number;
  bbox: [number, number, number, number];
}

export type ModelType = "accurate" | "fast";

export type FrameAnalysis = {
  all: Detection[];
  toAnnounce: Detection[];
};

const MODEL_BASE: Record<ModelType, "mobilenet_v2" | "lite_mobilenet_v2"> = {
  accurate: "mobilenet_v2",
  fast: "lite_mobilenet_v2",
};

const PRIORITY_MAP: Record<string, number> = {
  person: 1,
  car: 1,
  bus: 1,
  truck: 1,
  motorcycle: 1,
  bicycle: 2,
  dog: 2,
  cat: 2,
  chair: 3,
  couch: 3,
  bed: 3,
  "dining table": 3,
  laptop: 3,
  tv: 3,
  cell_phone: 3,
  bottle: 4,
  cup: 4,
  book: 4,
  clock: 4,
};

function getPriority(label: string): number {
  return PRIORITY_MAP[label.toLowerCase()] ?? 3;
}

export function useObjectDetection(modelType: ModelType = "accurate", enabled = true) {
  const [detections, setDetections] = useState<Detection[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [modelReady, setModelReady] = useState(false);
  const [loadFailed, setLoadFailed] = useState(false);
  const modelRef = useRef<cocoSsd.ObjectDetection | null>(null);
  const confirmationCountRef = useRef<Map<string, number>>(new Map());
  const spokenRef = useRef<Set<string>>(new Set());
  const FRAMES_TO_CONFIRM = 1;
  const FRAMES_TO_FORGET = 5;
  const absentCountRef = useRef<Map<string, number>>(new Map());

  useEffect(() => {
    if (!enabled) {
      setModelReady(false);
      setLoadFailed(false);
      modelRef.current = null;
      setDetections([]);
      confirmationCountRef.current.clear();
      absentCountRef.current.clear();
      spokenRef.current.clear();
      return;
    }

    let cancelled = false;
    setModelReady(false);
    setLoadFailed(false);
    modelRef.current = null;

    const load = async () => {
      await tf.ready();
      await tf.setBackend("webgl").catch(() => tf.setBackend("cpu"));
      const base = MODEL_BASE[modelType];
      try {
        const model = await cocoSsd.load({ base });
        if (!cancelled) {
          modelRef.current = model;
          setModelReady(true);
        }
      } catch {
        try {
          const fallback = await cocoSsd.load({ base: "lite_mobilenet_v2" });
          if (!cancelled) {
            modelRef.current = fallback;
            setModelReady(true);
          }
        } catch {
          if (!cancelled) {
            setModelReady(false);
            setLoadFailed(true);
          }
        }
      }
    };

    void load();

    return () => {
      cancelled = true;
    };
  }, [modelType, enabled]);

  const processFrame = useCallback(
    async (
      source: HTMLVideoElement | HTMLCanvasElement | HTMLImageElement | null,
      confidenceThreshold: number
    ): Promise<FrameAnalysis> => {
      const empty: FrameAnalysis = { all: [], toAnnounce: [] };
      if (!source || !modelRef.current) return empty;
      const ready =
        "readyState" in source
          ? source.readyState >= 2
          : "complete" in source
            ? source.complete
            : true;
      if (!ready) return empty;

      setIsProcessing(true);
      const now = Date.now();

      try {
        const predictions = await modelRef.current.detect(
          source as HTMLImageElement | HTMLCanvasElement | HTMLVideoElement
        );

        const filtered: Detection[] = predictions
          .filter((p) => p.score * 100 >= confidenceThreshold)
          .map((p) => ({
            label: p.class.charAt(0).toUpperCase() + p.class.slice(1),
            confidence: p.score * 100,
            priority: getPriority(p.class),
            timestamp: now,
            bbox: p.bbox as [number, number, number, number],
          }))
          .sort((a, b) => a.priority - b.priority || b.confidence - a.confidence);

        setDetections(filtered);

        const currentLabels = new Set(filtered.map((d) => d.label));
        const confirmMap = confirmationCountRef.current;
        const absentMap = absentCountRef.current;

        for (const label of currentLabels) {
          confirmMap.set(label, (confirmMap.get(label) ?? 0) + 1);
          absentMap.set(label, 0);
        }
        for (const label of Array.from(confirmMap.keys())) {
          if (!currentLabels.has(label)) {
            confirmMap.set(label, 0);
            const absent = (absentMap.get(label) ?? 0) + 1;
            absentMap.set(label, absent);
            if (absent >= FRAMES_TO_FORGET) {
              confirmMap.delete(label);
              absentMap.delete(label);
              spokenRef.current.delete(label);
            }
          }
        }

        const toAnnounce = filtered.filter((d) => {
          const count = confirmMap.get(d.label) ?? 0;
          const notSpoken = !spokenRef.current.has(d.label);
          return notSpoken && count >= FRAMES_TO_CONFIRM;
        });
        for (const d of toAnnounce) {
          spokenRef.current.add(d.label);
        }

        setIsProcessing(false);
        return { all: filtered, toAnnounce };
      } catch {
        setIsProcessing(false);
        return { all: [], toAnnounce: [] };
      }
    },
    []
  );

  return { detections, isProcessing, modelReady, loadFailed, processFrame };
}
