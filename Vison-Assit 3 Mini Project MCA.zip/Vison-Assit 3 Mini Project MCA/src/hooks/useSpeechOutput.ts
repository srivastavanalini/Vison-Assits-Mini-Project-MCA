import { useState, useCallback, useRef } from "react";
import type { Detection } from "./useObjectDetection";

export function useSpeechOutput(
  volume: number,
  setVolume: (v: number) => void,
  speechRate: number
) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const speak = useCallback(
    (detections: Detection[]) => {
      if (detections.length === 0 || !("speechSynthesis" in window)) return;

      window.speechSynthesis.cancel();

      const labels = [...new Set(detections.map((d) => d.label))];
      let text: string;
      if (labels.length === 1) {
        text = `${labels[0]} detected`;
      } else if (labels.length === 2) {
        text = `${labels[0]} and ${labels[1]} detected`;
      } else {
        text = `${labels.slice(0, -1).join(", ")}, and ${labels[labels.length - 1]} detected`;
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8 + speechRate * 0.6;
      utterance.volume = volume;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      utteranceRef.current = utterance;

      window.speechSynthesis.speak(utterance);
    },
    [volume, speechRate]
  );

  const speakText = useCallback(
    (text: string, immediate = false) => {
      if (!text || !("speechSynthesis" in window)) return;
      if (!immediate) window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9 + speechRate * 0.4;
      utterance.volume = volume;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    },
    [volume, speechRate]
  );

  const stop = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  return { isSpeaking, speak, speakText, stop, setVolume };
}
