import { useCallback, useEffect, useRef, useState } from "react";
import {
  analyzeFrame,
  type VisionBox,
  type VisionLabel,
} from "@/lib/visionApi";

const FRAME_INTERVAL_MS = 1500;

type Status = "idle" | "detecting" | "active";

let currentAudio: HTMLAudioElement | null = null;

function stopCurrentAudio(): void {
  if (!currentAudio) return;
  currentAudio.pause();
  currentAudio.currentTime = 0;
  currentAudio = null;
}

function playMp3Base64(b64: string, onEnd: () => void): void {
  currentAudio?.pause();
  currentAudio = new Audio(`data:audio/mp3;base64,${b64}`);
  currentAudio.onended = () => {
    currentAudio = null;
    onEnd();
  };
  currentAudio.onerror = () => {
    currentAudio = null;
    onEnd();
  };
  currentAudio.play().catch(() => {
    currentAudio = null;
    onEnd();
  });
}

export function useVisionAssist(
  sessionId: string,
  captureBlob: () => Promise<Blob | null>,
  isScanning: boolean
) {
  const [labels, setLabels] = useState<VisionLabel[]>([]);
  const [boxes, setBoxes] = useState<VisionBox[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [systemMessage, setSystemMessage] = useState("Camera idle.");
  const [lastSpoken, setLastSpoken] = useState<string | null>(null);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const labelsRef = useRef<VisionLabel[]>([]);
  const mounted = useRef(true);
  const inFlight = useRef(false);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const runOnce = useCallback(async () => {
    if (inFlight.current) return;
    const blob = await captureBlob();
    if (!blob || !mounted.current) return;

    inFlight.current = true;
    setIsProcessing(true);
    setError(null);
    try {
      const result = await analyzeFrame(blob, sessionId);
      if (!mounted.current) return;

      setSystemMessage(result.system_message);
      const next = [...result.labels].sort((a, b) => a.name.localeCompare(b.name));
      labelsRef.current = next;
      setLabels(next);
      setBoxes(result.boxes);

      if (result.spoken_text && result.audio_base64) {
        setLastSpoken(result.spoken_text);
        setAudioPlaying(true);
        playMp3Base64(result.audio_base64, () => {
          if (mounted.current) setAudioPlaying(false);
        });
      }
    } catch (e) {
      if (!mounted.current) return;
      const msg = e instanceof Error ? e.message : "Analysis failed.";
      labelsRef.current = [];
      setLabels([]);
      setBoxes([]);
      setError(msg);
      setSystemMessage(msg);
    } finally {
      inFlight.current = false;
      if (mounted.current) setIsProcessing(false);
    }
  }, [captureBlob, sessionId]);

  useEffect(() => {
    if (!isScanning) {
      setIsProcessing(false);
      return;
    }

    let cancelled = false;
    const tick = async () => {
      if (cancelled) return;
      await runOnce();
    };

    tick();
    const id = window.setInterval(tick, FRAME_INTERVAL_MS);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [isScanning, runOnce]);

  useEffect(() => {
    if (!isScanning) {
      setSystemMessage("Camera idle.");
      setLabels([]);
      setBoxes([]);
      setLastSpoken(null);
      setAudioPlaying(false);
      setError(null);
      inFlight.current = false;
      stopCurrentAudio();
    }
  }, [isScanning]);

  const status: Status = !isScanning
    ? "idle"
    : isProcessing
      ? "detecting"
      : "active";

  return {
    labels,
    boxes,
    isProcessing,
    systemMessage,
    lastSpoken,
    audioPlaying,
    error,
    status,
  };
}
