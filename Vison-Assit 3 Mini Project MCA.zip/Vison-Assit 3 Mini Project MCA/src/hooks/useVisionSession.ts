import { useMemo } from "react";

const KEY = "vision-assist-session";

function randomId(): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
}

export function useVisionSession(): string {
  return useMemo(() => {
    try {
      let id = localStorage.getItem(KEY);
      if (!id) {
        id = randomId();
        localStorage.setItem(KEY, id);
      }
      return id;
    } catch {
      return randomId();
    }
  }, []);
}
