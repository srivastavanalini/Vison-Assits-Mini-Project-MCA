import { useState, useCallback, useRef, useEffect } from "react";

interface UseVoiceCommandOptions {
  onCommand: (command: string) => void;
}

export function useVoiceCommand({ onCommand }: UseVoiceCommandOptions) {
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);

  const start = useCallback(() => {
    const SpeechRecognitionCtor =
      window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) return;

    const recognition = new SpeechRecognitionCtor();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = navigator.language || "en-US";

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const last = event.results[event.results.length - 1];
      if (last.isFinal) {
        const transcript = last[0].transcript.toLowerCase().trim();
        if (transcript.includes("scan now") || transcript.includes("scan")) {
          onCommand("scan");
        } else if (transcript.includes("stop")) {
          onCommand("stop");
        }
      }
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => {
      // Restart if still should be listening
      if (recognitionRef.current) {
        try {
          recognition.start();
        } catch {
          setIsListening(false);
        }
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
    setIsListening(true);
  }, [onCommand]);

  const stop = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.onend = null;
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setIsListening(false);
  }, []);

  useEffect(() => () => stop(), [stop]);

  return { isListening, start, stop };
}
