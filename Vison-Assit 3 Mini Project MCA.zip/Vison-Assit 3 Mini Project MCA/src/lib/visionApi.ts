const API_BASE = import.meta.env.VITE_API_URL ?? "";

export type VisionLabel = { name: string; confidence: number };
export type VisionBox = {
  label: string;
  confidence: number;
  bbox: [number, number, number, number];
};
export type HealthResult = {
  status: string;
  aws_ready?: boolean;
  detail?: string;
  region?: string;
  credentials_source?: string | null;
  rekognition_configured?: boolean;
  polly_configured?: boolean;
};

export type AnalyzeResult = {
  labels: VisionLabel[];
  boxes: VisionBox[];
  spoken_text: string | null;
  audio_base64: string | null;
  system_message: string;
};

export async function analyzeFrame(
  blob: Blob,
  sessionId: string
): Promise<AnalyzeResult> {
  let res: Response;
  try {
    const fd = new FormData();
    fd.append("file", blob, "frame.jpg");

    res = await fetch(`${API_BASE}/api/analyze`, {
      method: "POST",
      body: fd,
      headers: {
        "X-Session-Id": sessionId,
      },
    });
  } catch {
    throw new Error("Could not reach the backend service.");
  }

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    const contentType = res.headers.get("content-type") ?? "";

    if (contentType.includes("application/json")) {
      const payload = (await res.json()) as { detail?: string };
      if (payload.detail) {
        message = payload.detail;
      }
    } else {
      const err = await res.text();
      if (err) {
        message = err;
      }
    }

    throw new Error(message);
  }

  return res.json() as Promise<AnalyzeResult>;
}

export async function checkHealth(): Promise<HealthResult> {
  try {
    const res = await fetch(`${API_BASE}/api/aws/status`, { method: "GET" });
    if (!res.ok) {
      let detail = `Health check failed (${res.status})`;
      const contentType = res.headers.get("content-type") ?? "";

      if (contentType.includes("application/json")) {
        const payload = (await res.json()) as { detail?: string };
        if (payload.detail) {
          detail = payload.detail;
        }
      } else {
        const text = await res.text();
        if (text.includes("ECONNREFUSED") || text.includes("127.0.0.1:8000")) {
          detail = "Backend API is not running on http://127.0.0.1:8000. Start the FastAPI server first.";
        } else if (
          res.status >= 500 &&
          (!text.trim() || text.includes("Internal Server Error"))
        ) {
          detail =
            "Backend API returned an internal error. Restart the FastAPI server and check the backend terminal for details.";
        } else if (text.trim()) {
          detail = text.trim();
        }
      }

      return {
        status: "error",
        aws_ready: false,
        detail,
      };
    }
    return (await res.json()) as HealthResult;
  } catch {
    return {
      status: "error",
      aws_ready: false,
      detail: "Could not reach the backend service.",
    };
  }
}
