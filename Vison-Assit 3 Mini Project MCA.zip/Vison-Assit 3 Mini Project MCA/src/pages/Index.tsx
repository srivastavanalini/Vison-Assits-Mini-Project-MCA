import { useCallback, useEffect, useState } from "react";
import { Eye, EyeOff, RefreshCcw } from "lucide-react";
import { VisionNav } from "@/components/vision/VisionNav";
import { VisionCameraPanel } from "@/components/vision/VisionCameraPanel";
import { VisionObjectsPanel } from "@/components/vision/VisionObjectsPanel";
import { VisionFooter, type VisionMode } from "@/components/vision/VisionFooter";
import { useWebcam } from "@/hooks/useWebcam";
import { useVisionSession } from "@/hooks/useVisionSession";
import { useVisionAssist } from "@/hooks/useVisionAssist";
import { useLocalVisionAssist } from "@/hooks/useLocalVisionAssist";
import { checkHealth } from "@/lib/visionApi";

export default function Index() {
  const [isScanning, setIsScanning] = useState(false);
  const [backendOk, setBackendOk] = useState<boolean | null>(null);
  const [backendDetail, setBackendDetail] = useState<string | null>(null);
  const [awsRegion, setAwsRegion] = useState<string | null>(null);
  const [credentialsSource, setCredentialsSource] = useState<string | null>(null);
  const [mode, setMode] = useState<VisionMode>("local");
  const [overlayVisible, setOverlayVisible] = useState(true);

  const sessionId = useVisionSession();
  const { videoRef, isActive, error, start, stop, captureFrameAsBlob } = useWebcam();

  const captureBlob = useCallback(() => captureFrameAsBlob(), [captureFrameAsBlob]);

  const awsOn = mode === "aws" && isScanning && isActive && backendOk === true;
  const localOn = mode === "local" && isScanning && isActive;

  const cloud = useVisionAssist(sessionId, captureBlob, awsOn);
  const local = useLocalVisionAssist(videoRef, localOn, mode === "local");

  const refreshAwsHealth = useCallback(() => {
    if (mode !== "aws") return;
    checkHealth().then((health) => {
      setBackendOk(Boolean(health.aws_ready));
      setBackendDetail(health.detail ?? null);
      setAwsRegion(health.region ?? null);
      setCredentialsSource(health.credentials_source ?? null);
    });
  }, [mode]);

  useEffect(() => {
    setIsScanning(false);
    stop();
  }, [mode, stop]);

  useEffect(() => {
    if (mode !== "aws") {
      setBackendOk(null);
      setBackendDetail(null);
      setAwsRegion(null);
      setCredentialsSource(null);
      return;
    }

    let cancelled = false;
    const update = () => {
      checkHealth().then((health) => {
        if (!cancelled) {
          setBackendOk(Boolean(health.aws_ready));
          setBackendDetail(health.detail ?? null);
          setAwsRegion(health.region ?? null);
          setCredentialsSource(health.credentials_source ?? null);
        }
      });
    };

    update();
    const id = window.setInterval(update, 5000);
    const onFocus = () => update();
    window.addEventListener("focus", onFocus);

    return () => {
      cancelled = true;
      window.clearInterval(id);
      window.removeEventListener("focus", onFocus);
    };
  }, [mode]);

  const labels = mode === "aws" ? cloud.labels : local.labels;
  const isProcessing = mode === "aws" ? cloud.isProcessing : local.isProcessing;
  const systemMessage = mode === "aws" ? cloud.systemMessage : local.systemMessage;
  const lastSpoken = mode === "aws" ? cloud.lastSpoken : local.lastSpoken;
  const audioPlaying = mode === "aws" ? cloud.audioPlaying : local.audioPlaying;
  const apiError = mode === "aws" ? cloud.error : local.error;
  const status = mode === "aws" ? cloud.status : local.status;

  const waitingForModel =
    mode === "local" && isScanning && !local.modelReady && !local.loadFailed;

  const toggle = useCallback(async () => {
    if (isScanning) {
      setIsScanning(false);
      stop();
      return;
    }
    if (mode === "aws" && backendOk === false) {
      refreshAwsHealth();
      return;
    }
    const ok = await start();
    if (ok) setIsScanning(true);
  }, [backendOk, isScanning, mode, refreshAwsHealth, start, stop]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (e.code === "Space") {
        e.preventDefault();
        toggle();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle]);

  const combinedError =
    apiError ?? error ?? (mode === "aws" && backendOk === false ? backendDetail : null);

  const modeDescription =
    mode === "aws"
      ? "Frames are sent to your backend and analyzed with AWS Rekognition. Speech uses Amazon Polly."
      : 'On-device COCO-SSD draws boxes at 50%+ confidence and speaks phrases like "I see a person" using your system voice. Point the camera at clear, well-lit scenes.';

  const healthNotice =
    mode === "aws" && backendOk === false
      ? backendDetail ?? "Backend API is not available yet."
      : mode === "aws" && backendOk === true
        ? "AWS cloud services are connected and ready."
        : "On-device mode works entirely in the browser.";

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_#1e293b_0%,_#0f172a_22%,_#020617_100%)] p-2 text-neutral-900 sm:p-4">
      <main className="mx-auto max-w-[1680px]">
        <div className="relative overflow-hidden rounded-[28px] bg-black shadow-[0_24px_80px_rgba(0,0,0,0.42)] ring-1 ring-white/10">
          <VisionCameraPanel
            videoRef={videoRef}
            isActive={isActive}
            error={combinedError}
            isScanning={isScanning}
            boxDetections={mode === "local" ? local.detections : cloud.boxes}
            immersive
            className="min-h-[100svh] sm:min-h-[calc(100vh-2rem)]"
          />

          <button
            type="button"
            onClick={() => setOverlayVisible((visible) => !visible)}
            className="pointer-events-auto absolute right-4 top-4 z-30 inline-flex items-center gap-2 rounded-full bg-black/55 px-3 py-2 text-sm font-medium text-white ring-1 ring-white/12 backdrop-blur-xl transition hover:bg-black/65"
          >
            {overlayVisible ? (
              <>
                <EyeOff className="h-4 w-4" aria-hidden />
                Hide UI
              </>
            ) : (
              <>
                <Eye className="h-4 w-4" aria-hidden />
                Show UI
              </>
            )}
          </button>

          {overlayVisible && (
            <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3 sm:p-5 lg:p-6">
              <VisionNav
                status={status}
                awsReady={mode === "aws" ? backendOk : null}
                compact
                className="pointer-events-auto max-w-fit"
              />

              <div className="grid items-end gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
                <div className="pointer-events-auto flex max-w-3xl flex-col gap-4">
                  <div className="rounded-[28px] bg-black/58 p-5 text-white shadow-[0_18px_40px_rgba(0,0,0,0.26)] ring-1 ring-white/10 backdrop-blur-xl sm:p-6">
                    <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
                      <div className="space-y-3">
                        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-200/80">
                          Real-time scene awareness
                        </p>
                        <h1 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                          A bigger live camera with the controls inside the frame.
                        </h1>
                        <p className="max-w-2xl text-sm leading-relaxed text-white/75 sm:text-[15px]">
                          {modeDescription}
                        </p>
                        <div
                          className="inline-flex rounded-full bg-white/8 p-1 ring-1 ring-white/10"
                          role="group"
                          aria-label="Analysis mode"
                        >
                          <button
                            type="button"
                            onClick={() => setMode("local")}
                            className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                              mode === "local"
                                ? "bg-white text-neutral-950 shadow-sm"
                                : "text-white/70 hover:text-white"
                            }`}
                          >
                            On-device
                          </button>
                          <button
                            type="button"
                            onClick={() => setMode("aws")}
                            className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                              mode === "aws"
                                ? "bg-white text-neutral-950 shadow-sm"
                                : "text-white/70 hover:text-white"
                            }`}
                          >
                            AWS cloud
                          </button>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <span className="rounded-full bg-white/10 px-3 py-1.5 text-xs text-white/70 ring-1 ring-white/10">
                          Shortcut: Space
                        </span>
                        {mode === "aws" && (
                          <button
                            type="button"
                            onClick={refreshAwsHealth}
                            className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-white/10 px-4 text-sm font-medium text-white ring-1 ring-white/10 transition hover:bg-white/16"
                          >
                            <RefreshCcw className="h-4 w-4" aria-hidden />
                            Retry health
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={toggle}
                          disabled={mode === "aws" && backendOk === false}
                          className="inline-flex h-11 items-center justify-center rounded-full bg-white px-5 text-sm font-medium text-neutral-950 shadow-sm transition hover:bg-white/90 disabled:cursor-not-allowed disabled:bg-white/25 disabled:text-white/45"
                        >
                          {isScanning ? "Stop detection" : "Start detection"}
                        </button>
                      </div>
                    </div>

                    <div className="mt-5 flex flex-wrap gap-2 text-xs text-white/70">
                      <span className="rounded-full bg-white/10 px-3 py-1.5 ring-1 ring-white/10">
                        Camera {isActive ? "ready" : "idle"}
                      </span>
                      <span className="rounded-full bg-white/10 px-3 py-1.5 ring-1 ring-white/10">
                        Mode {mode === "aws" ? "AWS cloud" : "On-device"}
                      </span>
                      {mode === "aws" && awsRegion && (
                        <span className="rounded-full bg-white/10 px-3 py-1.5 ring-1 ring-white/10">
                          Region {awsRegion}
                        </span>
                      )}
                      {mode === "aws" && credentialsSource && (
                        <span className="rounded-full bg-white/10 px-3 py-1.5 ring-1 ring-white/10">
                          Credentials {credentialsSource}
                        </span>
                      )}
                    </div>

                    <div
                      className={`mt-5 rounded-[20px] border px-4 py-3 text-sm ${
                        mode === "aws" && backendOk === false
                          ? "border-amber-300/25 bg-amber-300/10 text-amber-100"
                          : "border-white/10 bg-white/7 text-white/78"
                      }`}
                    >
                      {healthNotice}
                      {mode === "aws" && backendOk === false && (
                        <div className="mt-2 text-xs text-amber-100/85">
                          Start the FastAPI backend on port 8000, then press Retry health.
                        </div>
                      )}
                    </div>
                  </div>

                  {lastSpoken && (
                    <div className="rounded-[22px] bg-black/45 px-4 py-3 text-sm text-white/78 ring-1 ring-white/10 backdrop-blur-xl">
                      Last spoken: <span className="text-white">{lastSpoken}</span>
                    </div>
                  )}

                  <VisionFooter
                    systemMessage={systemMessage}
                    audioPlaying={audioPlaying}
                    backendOk={backendOk}
                    backendDetail={backendDetail}
                    awsRegion={awsRegion}
                    credentialsSource={credentialsSource}
                    mode={mode}
                    embedded
                  />
                </div>

                <VisionObjectsPanel
                  labels={labels}
                  isProcessing={isProcessing}
                  waitingForModel={waitingForModel}
                  error={combinedError}
                  overlay
                  className="pointer-events-auto"
                />
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
