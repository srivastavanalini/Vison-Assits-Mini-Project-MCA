import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#fafafa] px-4">
      <p className="text-sm font-medium text-neutral-900">Page not found</p>
      <p className="mt-1 text-sm text-neutral-500">The page you requested does not exist.</p>
      <Link
        to="/"
        className="mt-6 text-sm font-medium text-[hsl(var(--accent))] underline-offset-4 hover:underline"
      >
        Back to app
      </Link>
    </div>
  );
};

export default NotFound;
